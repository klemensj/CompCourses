word = 'BANANA'

print()
print(word + '!')
print()

for i in word:
   print('Gimmee a ' + i)
    
print()
print(word + '!')
print()